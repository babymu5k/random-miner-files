This is Duinocoin miner 1.5.1 Lite
created by superpythonguy
please make sure to check for new updates