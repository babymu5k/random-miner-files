print("Duinocoin miner 1.5.1 Lite")
print("Based on a custom architecture")
#-------------------------------------#
refresh_time = 2.0
autorestart_time = 500
print("This could be inefficient ")
print("this could also be optimized for older PCs")
#-------------------------------------#
import time
import os
import hashlib
from colorama import init
init()
from colorama import Fore, Back, Style
import random
import sys
from socket import socket
import json
import requests
import ssl
import select
import datetime
import statistics
import pip

def ctime():
    t = time.localtime()
    ctime = time.strftime("%H:%M:%S", t)
    return ctime

soc = socket()

time.sleep(1)
greetings = ("Hello and thanks for using me Experimental duinocoin miner", "DUINOCOINSSS!!", "DuinoCoin made is a coin made by Revox and many others")
rg = random.choice(greetings)
print(rg)

print(Back.RED + "This is a Duinocoin miner V1.5.1 Lite ")
print(Back.RED + "Created By SuperPythonGuy")
print(Style.RESET_ALL)
time.sleep(1)
print("Starting miner")
print("...waiting...")
time.sleep(1)
if sys.platform == "win32":
    try:
        from colorama import Back, Fore, Style, init
        init()

    except:
        print("You don't have colorama installed will install for you")
        os.system("pip install colorama")
        os.exit(1)

if sys.platform == "win32":
    try:
        from requests import requests
    except:
        print("you dont have requests installed will install for you")
        os.system("pip install requests")


print(Back.WHITE)
print(Fore.BLACK + "Basic miner V1.5.1 lite")
print(Style.RESET_ALL)
dusr = input("what is your DuinoCoin Username \n>>?")

diff_choice = input("do you want to use low or normal difficulty(low for old PCs and rasp) yes or no\n>>>")
if diff_choice == "yes":
    print("you chonsen yes")
    useldiff = True
else:
    print("you have chosen no")
    useldiff = False


def hashrateCalculator(): #internal hash calculater
    global last_hash_count, hash_count, khash_count, hash_mean

    last_hash_count = hash_count
    khash_count = last_hash_count / 1000
    if khash_count == 0:
        khash_count = random.uniform(0, 1)

    hash_mean.append(khash_count)
    khash_count = statistics.mean(hash_mean)
    khash_count = round(khash_count, 2)

    hash_count = 0

    threading.Timer(1.0, hashrateCalculator).start()



def get_pools():
    while True:
        try:
            res = requests.get(
                "https://server.duinocoin.com/getPool"
                ).json()

            duinoip = res["ip"]
            port = res["port"]

            return duinoip, port
        except Exception as e:
            print (f'{ctime()} : Error retrieving mining node, retrying in 3s') # if it fails
            time.sleep(3)

while True:                                        # loop
    try:
        print(f"{ctime()} : finding quickest connection to the Duinocoin servers")
        print("...waiting...")
        try:
            duinoip, port = get_pools()
        except Exception as e:
            duinoip = "server.duinocoin.com"
            port = 2813
            print(f'{ctime()} : getting Duinos default server port and address get ready to mine :)')


        soc.connect((str(duinoip), int(port)))
        print(f"{ctime()} : Stable connection has been found")
        print("almost ready to mine")
        server_version = soc.recv(100).decode()
        print("server version is", server_version)

        while True:
            if useldiff:
                soc.send(bytes(
                    "JOB,"
                    + str(dusr)
                    + ",MEDIUM",
                    encoding="utf8"))

            else:
                soc.send(bytes(
                    "JOB,"
                    + str(dusr),
                    encoding="utf8"))

            job = soc.recv(1024).decode().rstrip("\n")

            job = job.split(",")
            difficulty = job[2]

            hashingStartTime = time.time()
            base_hash = hashlib.sha1(str(job[0]).encode('ascii'))
            temp_hash = None

            for result in range(1000 * int(difficulty) + 1):
                temp_hash = base_hash.copy()
                temp_hash.update(str(result).encode('ascii'))
                ducos1 = temp_hash.hexdigest()

                if job[1] == ducos1:
                    hashingStopTime = time.time()
                    timeDifference = hashingStopTime - hashingStartTime
                    hashrate = result / timeDifference

                    soc.send(bytes(
                        str(result)
                        + ","
                        + str(hashrate)
                        + ",[PythonMiner V1.5.1 Lite]",
                        encoding="utf8"))

                    feedback = soc.recv(1024).decode().rstrip("\n")
                    if feedback == "GOOD":
                        print(f'{ctime()} : share is accepted',
                            result,
                            "Hashrate",
                            int(hashrate / 1000),
                            "kH/s (unit used to measure hash per second)",
                            "Difficulty is",
                            difficulty)
                        break

                    elif feedback == "BAD":
                        print(f'{ctime()} : share is Rejected',
                            result,
                            "Hashrate",
                            int(hashrate / 1000),
                            "kH/s",
                            "Difficulty is",
                            difficulty)
                        break

    except Exception as e:
        print(f'{ctime()} : Error occured: ' + str(e) + ", restarting in 3s.")
        time.sleep(3)
        os.execl(sys.executable, sys.executable, *sys.argv)