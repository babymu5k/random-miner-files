This is a modifyed version of minimal pc miner
this could be more optimised for old PCs(yet to test)
Duino coin is  a coin mined by SBCs arduinos and many more